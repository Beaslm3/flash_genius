# FlashGenius - AI-Powered Study Cards

A complete React application for creating and studying with AI-generated flashcards.

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Build for Production

```bash
npm run build
```

## Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow the prompts

Or simply drag the build folder to [vercel.com](https://vercel.com)

## Features

- Beautiful landing page
- Dashboard with statistics
- Multiple page navigation
- Responsive design
- Ready for AI integration
- Production-ready build

## Tech Stack

- React 18
- React Router
- Tailwind CSS
- Lucide React Icons
- Framer Motion (ready to use)

Built with ❤️ by FlashGenius