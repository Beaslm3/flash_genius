import React from 'react';
import { ArrowLeft, ClipboardCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Test() {
  return (
    <div data-filename="pages/CodeExporter" data-linenumber="506" data-visual-selector-id="pages/CodeExporter506" className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div data-filename="pages/CodeExporter" data-linenumber="507" data-visual-selector-id="pages/CodeExporter507" className="max-w-4xl mx-auto">
        <div data-filename="pages/CodeExporter" data-linenumber="508" data-visual-selector-id="pages/CodeExporter508" className="flex items-center gap-4 mb-8">
          <Link data-filename="pages/CodeExporter" data-linenumber="509" data-visual-selector-id="pages/CodeExporter509" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="510" data-visual-selector-id="pages/CodeExporter510" className="bg-white/80 backdrop-blur-sm border border-slate-200 p-2 rounded-lg hover:bg-white">
              <ArrowLeft data-filename="pages/CodeExporter" data-linenumber="511" data-visual-selector-id="pages/CodeExporter511" className="w-4 h-4" />
            </button>
          </Link>
          <div data-filename="pages/CodeExporter" data-linenumber="514" data-visual-selector-id="pages/CodeExporter514">
            <h1 className="text-3xl font-bold text-slate-900">Take Test</h1>
            <p data-filename="pages/CodeExporter" data-linenumber="516" data-visual-selector-id="pages/CodeExporter516" className="text-slate-600 mt-1">Test your knowledge with comprehensive assessments</p>
          </div>
        </div>

        <div data-filename="pages/CodeExporter" data-linenumber="520" data-visual-selector-id="pages/CodeExporter520" className="bg-white/80 backdrop-blur-sm shadow-xl border-0 rounded-lg p-8 text-center">
          <ClipboardCheck data-filename="pages/CodeExporter" data-linenumber="521" data-visual-selector-id="pages/CodeExporter521" className="w-16 h-16 text-green-500 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Testing Mode Coming Soon!</h2>
          <p data-filename="pages/CodeExporter" data-linenumber="523" data-visual-selector-id="pages/CodeExporter523" className="text-slate-600 mb-8">
            Create some flashcard sets first, then come back to test your knowledge with our comprehensive testing system.
          </p>
          <Link data-filename="pages/CodeExporter" data-linenumber="526" data-visual-selector-id="pages/CodeExporter526" to="/create">
            <button data-filename="pages/CodeExporter" data-linenumber="527" data-visual-selector-id="pages/CodeExporter527" className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 py-3 rounded-lg font-semibold mr-4">
              Create Flashcards
            </button>
          </Link>
          <Link data-filename="pages/CodeExporter" data-linenumber="531" data-visual-selector-id="pages/CodeExporter531" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="532" data-visual-selector-id="pages/CodeExporter532" className="bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 px-6 py-3 rounded-lg font-semibold">
              Back to Dashboard
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}