import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Create from './pages/Create';
import Study from './pages/Study';
import Test from './pages/Test';

function App() {
  return (
    <Router data-filename="pages/CodeExporter" data-linenumber="116" data-visual-selector-id="pages/CodeExporter116">
      <Layout data-filename="pages/CodeExporter" data-linenumber="117" data-visual-selector-id="pages/CodeExporter117">
        <Routes data-filename="pages/CodeExporter" data-linenumber="118" data-visual-selector-id="pages/CodeExporter118">
          <Route data-filename="pages/CodeExporter" data-linenumber="119" data-visual-selector-id="pages/CodeExporter119" path="/" element={<Navigate data-filename='pages/CodeExporter' data-linenumber='119' data-visual-selector-id='pages/CodeExporter119' to="/home" replace />} />
          <Route data-filename="pages/CodeExporter" data-linenumber="120" data-visual-selector-id="pages/CodeExporter120" path="/home" element={<Home data-filename='pages/CodeExporter' data-linenumber='120' data-visual-selector-id='pages/CodeExporter120' />} />
          <Route data-filename="pages/CodeExporter" data-linenumber="121" data-visual-selector-id="pages/CodeExporter121" path="/dashboard" element={<Dashboard data-filename='pages/CodeExporter' data-linenumber='121' data-visual-selector-id='pages/CodeExporter121' />} />
          <Route data-filename="pages/CodeExporter" data-linenumber="122" data-visual-selector-id="pages/CodeExporter122" path="/create" element={<Create data-filename='pages/CodeExporter' data-linenumber='122' data-visual-selector-id='pages/CodeExporter122' />} />
          <Route data-filename="pages/CodeExporter" data-linenumber="123" data-visual-selector-id="pages/CodeExporter123" path="/study" element={<Study data-filename='pages/CodeExporter' data-linenumber='123' data-visual-selector-id='pages/CodeExporter123' />} />
          <Route data-filename="pages/CodeExporter" data-linenumber="124" data-visual-selector-id="pages/CodeExporter124" path="/test" element={<Test data-filename='pages/CodeExporter' data-linenumber='124' data-visual-selector-id='pages/CodeExporter124' />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;