import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Library, Plus, Brain, ClipboardCheck, Sparkles } from 'lucide-react';

const navigationItems = [
  { title: 'Home', url: '/home', icon: Home },
  { title: 'Dashboard', url: '/dashboard', icon: Library },
  { title: 'Create Flashcards', url: '/create', icon: Plus },
  { title: 'Study Mode', url: '/study', icon: Brain },
  { title: 'Take Test', url: '/test', icon: ClipboardCheck },
];

export default function Layout({ children }) {
  const location = useLocation();
  
  if (location.pathname === '/home') {
    return <div data-filename="pages/CodeExporter" data-linenumber="148" data-visual-selector-id="pages/CodeExporter148" className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">{children}</div>;
  }

  return (
    <div data-filename="pages/CodeExporter" data-linenumber="152" data-visual-selector-id="pages/CodeExporter152" className="min-h-screen flex bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <aside data-filename="pages/CodeExporter" data-linenumber="153" data-visual-selector-id="pages/CodeExporter153" className="w-64 bg-white/80 backdrop-blur-sm border-r border-slate-200/50 hidden md:flex flex-col">
        <div data-filename="pages/CodeExporter" data-linenumber="154" data-visual-selector-id="pages/CodeExporter154" className="border-b border-slate-200/50 p-6">
          <Link data-filename="pages/CodeExporter" data-linenumber="155" data-visual-selector-id="pages/CodeExporter155" to="/home" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div data-filename="pages/CodeExporter" data-linenumber="156" data-visual-selector-id="pages/CodeExporter156" className="w-10 h-10 flashcard-gradient rounded-xl flex items-center justify-center shadow-lg">
              <Sparkles data-filename="pages/CodeExporter" data-linenumber="157" data-visual-selector-id="pages/CodeExporter157" className="w-6 h-6 text-white" />
            </div>
            <div data-filename="pages/CodeExporter" data-linenumber="159" data-visual-selector-id="pages/CodeExporter159">
              <h2 className="font-bold text-xl text-slate-900">FlashGenius</h2>
              <p data-filename="pages/CodeExporter" data-linenumber="161" data-visual-selector-id="pages/CodeExporter161" className="text-xs text-slate-500 font-medium">AI-Powered Study Cards</p>
            </div>
          </Link>
        </div>
        
        <nav data-filename="pages/CodeExporter" data-linenumber="166" data-visual-selector-id="pages/CodeExporter166" className="p-4 flex-1">
          <div data-filename="pages/CodeExporter" data-linenumber="167" data-visual-selector-id="pages/CodeExporter167" className="space-y-2">
            {navigationItems.map((item) => (
              <Link
                key={item.title}
                to={item.url}
                className={`flex items-center gap-3 hover:bg-amber-50 hover:text-amber-700 transition-all duration-200 rounded-xl py-3 px-4 ${
                  location.pathname === item.url ? 'bg-amber-50 text-amber-700 shadow-sm border border-amber-200' : 'text-slate-600'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span data-filename="pages/CodeExporter" data-linenumber="177" data-visual-selector-id="pages/CodeExporter177" className="font-medium">{item.title}</span>
              </Link>
            ))}
          </div>
        </nav>
      </aside>

      <main data-filename="pages/CodeExporter" data-linenumber="184" data-visual-selector-id="pages/CodeExporter184" className="flex-1 overflow-auto study-pattern">
        {children}
      </main>
    </div>
  );
}