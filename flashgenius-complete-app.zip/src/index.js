import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App data-filename="pages/CodeExporter" data-linenumber="102" data-visual-selector-id="pages/CodeExporter102" />
  </React.StrictMode>
);