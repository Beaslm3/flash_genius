import React from 'react';
import { ArrowLeft, Brain } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Study() {
  return (
    <div data-filename="pages/CodeExporter" data-linenumber="465" data-visual-selector-id="pages/CodeExporter465" className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div data-filename="pages/CodeExporter" data-linenumber="466" data-visual-selector-id="pages/CodeExporter466" className="max-w-4xl mx-auto">
        <div data-filename="pages/CodeExporter" data-linenumber="467" data-visual-selector-id="pages/CodeExporter467" className="flex items-center gap-4 mb-8">
          <Link data-filename="pages/CodeExporter" data-linenumber="468" data-visual-selector-id="pages/CodeExporter468" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="469" data-visual-selector-id="pages/CodeExporter469" className="bg-white/80 backdrop-blur-sm border border-slate-200 p-2 rounded-lg hover:bg-white">
              <ArrowLeft data-filename="pages/CodeExporter" data-linenumber="470" data-visual-selector-id="pages/CodeExporter470" className="w-4 h-4" />
            </button>
          </Link>
          <div data-filename="pages/CodeExporter" data-linenumber="473" data-visual-selector-id="pages/CodeExporter473">
            <h1 className="text-3xl font-bold text-slate-900">Study Mode</h1>
            <p data-filename="pages/CodeExporter" data-linenumber="475" data-visual-selector-id="pages/CodeExporter475" className="text-slate-600 mt-1">Interactive study sessions with progress tracking</p>
          </div>
        </div>

        <div data-filename="pages/CodeExporter" data-linenumber="479" data-visual-selector-id="pages/CodeExporter479" className="bg-white/80 backdrop-blur-sm shadow-xl border-0 rounded-lg p-8 text-center">
          <Brain data-filename="pages/CodeExporter" data-linenumber="480" data-visual-selector-id="pages/CodeExporter480" className="w-16 h-16 text-blue-500 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Study Mode Coming Soon!</h2>
          <p data-filename="pages/CodeExporter" data-linenumber="482" data-visual-selector-id="pages/CodeExporter482" className="text-slate-600 mb-8">
            Create some flashcard sets first, then come back to study them with our interactive study mode.
          </p>
          <Link data-filename="pages/CodeExporter" data-linenumber="485" data-visual-selector-id="pages/CodeExporter485" to="/create">
            <button data-filename="pages/CodeExporter" data-linenumber="486" data-visual-selector-id="pages/CodeExporter486" className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white px-6 py-3 rounded-lg font-semibold mr-4">
              Create Flashcards
            </button>
          </Link>
          <Link data-filename="pages/CodeExporter" data-linenumber="490" data-visual-selector-id="pages/CodeExporter490" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="491" data-visual-selector-id="pages/CodeExporter491" className="bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 px-6 py-3 rounded-lg font-semibold">
              Back to Dashboard
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}