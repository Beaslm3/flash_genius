import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Brain, ClipboardCheck, Sparkles, BookOpen } from 'lucide-react';

export default function Home() {
  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Generation",
      description: "Create flashcards instantly using AI from any topic or uploaded document",
      color: "text-amber-500"
    },
    {
      icon: Brain,
      title: "Smart Study Mode",
      description: "Interactive study sessions with progress tracking and performance analytics",
      color: "text-blue-500"
    },
    {
      icon: ClipboardCheck,
      title: "Comprehensive Testing",
      description: "Take tests with multiple formats: text input, voice recognition, and multiple choice",
      color: "text-green-500"
    },
    {
      icon: BookOpen,
      title: "Export to Books",
      description: "Turn your flashcards into professional books ready for Amazon KDP publishing",
      color: "text-purple-500"
    }
  ];

  const stats = [
    { number: "1000+", label: "Flashcard Sets Created" },
    { number: "50+", label: "Languages Supported" },
    { number: "10,000+", label: "Questions Generated" },
    { number: "95%", label: "User Success Rate" }
  ];

  return (
    <div data-filename="pages/CodeExporter" data-linenumber="230" data-visual-selector-id="pages/CodeExporter230" className="min-h-screen">
      {/* Hero Section */}
      <div data-filename="pages/CodeExporter" data-linenumber="232" data-visual-selector-id="pages/CodeExporter232" className="relative text-white overflow-hidden">
        <div data-filename="pages/CodeExporter" data-linenumber="233" data-visual-selector-id="pages/CodeExporter233" className="absolute inset-0 flashcard-gradient" />
        <div data-filename="pages/CodeExporter" data-linenumber="234" data-visual-selector-id="pages/CodeExporter234" className="absolute inset-0 bg-gradient-to-r from-indigo-900/40 to-purple-900/40" />
        <div data-filename="pages/CodeExporter" data-linenumber="235" data-visual-selector-id="pages/CodeExporter235" className="relative max-w-7xl mx-auto px-6 py-20 md:py-32">
          <div data-filename="pages/CodeExporter" data-linenumber="236" data-visual-selector-id="pages/CodeExporter236" className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
              Master Any Subject with AI
            </h1>
            <p data-filename="pages/CodeExporter" data-linenumber="240" data-visual-selector-id="pages/CodeExporter240" className="text-xl md:text-2xl text-blue-100 mb-10 max-w-4xl mx-auto font-light">
              Create intelligent flashcards in any language, study smarter with AI-powered tools, and export professional study materials.
            </p>
            <div data-filename="pages/CodeExporter" data-linenumber="243" data-visual-selector-id="pages/CodeExporter243" className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Link data-filename="pages/CodeExporter" data-linenumber="244" data-visual-selector-id="pages/CodeExporter244" to="/create">
                <button data-filename="pages/CodeExporter" data-linenumber="245" data-visual-selector-id="pages/CodeExporter245" className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 px-8 py-4 text-lg rounded-lg font-semibold">
                  <Plus data-filename="pages/CodeExporter" data-linenumber="246" data-visual-selector-id="pages/CodeExporter246" className="w-6 h-6 mr-3 inline" />
                  Start Creating Free
                </button>
              </Link>
              <Link data-filename="pages/CodeExporter" data-linenumber="250" data-visual-selector-id="pages/CodeExporter250" to="/dashboard">
                <button data-filename="pages/CodeExporter" data-linenumber="251" data-visual-selector-id="pages/CodeExporter251" className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 px-8 py-4 text-lg rounded-lg font-semibold">
                  <BookOpen data-filename="pages/CodeExporter" data-linenumber="252" data-visual-selector-id="pages/CodeExporter252" className="w-6 h-6 mr-3 inline" />
                  View Dashboard
                </button>
              </Link>
            </div>

            {/* Stats */}
            <div data-filename="pages/CodeExporter" data-linenumber="259" data-visual-selector-id="pages/CodeExporter259" className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              {stats.map((stat, index) => (
                <div data-filename="pages/CodeExporter" data-linenumber="261" data-visual-selector-id="pages/CodeExporter261" key={index} className="text-center">
                  <div data-filename="pages/CodeExporter" data-linenumber="262" data-visual-selector-id="pages/CodeExporter262" className="text-3xl md:text-4xl font-bold text-white mb-2">{stat.number}</div>
                  <div data-filename="pages/CodeExporter" data-linenumber="263" data-visual-selector-id="pages/CodeExporter263" className="text-blue-200 text-sm md:text-base">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div data-filename="pages/CodeExporter" data-linenumber="272" data-visual-selector-id="pages/CodeExporter272" className="bg-gradient-to-b from-slate-50 to-white py-20">
        <div data-filename="pages/CodeExporter" data-linenumber="273" data-visual-selector-id="pages/CodeExporter273" className="max-w-7xl mx-auto px-6">
          <div data-filename="pages/CodeExporter" data-linenumber="274" data-visual-selector-id="pages/CodeExporter274" className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Everything You Need to Learn
            </h2>
            <p data-filename="pages/CodeExporter" data-linenumber="278" data-visual-selector-id="pages/CodeExporter278" className="text-xl text-slate-600 max-w-3xl mx-auto">
              Powerful AI tools and study features designed to help you master any subject faster and more effectively.
            </p>
          </div>

          <div data-filename="pages/CodeExporter" data-linenumber="283" data-visual-selector-id="pages/CodeExporter283" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div data-filename="pages/CodeExporter" data-linenumber="285" data-visual-selector-id="pages/CodeExporter285" key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 rounded-lg p-6">
                <div data-filename="pages/CodeExporter" data-linenumber="286" data-visual-selector-id="pages/CodeExporter286" className="text-center">
                  <div data-filename="pages/CodeExporter" data-linenumber="287" data-visual-selector-id="pages/CodeExporter287" className={`w-16 h-16 ${feature.color} bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-4">
                    {feature.title}
                  </h3>
                  <p data-filename="pages/CodeExporter" data-linenumber="293" data-visual-selector-id="pages/CodeExporter293" className="text-slate-600 text-center leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}