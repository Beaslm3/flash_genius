import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Create() {
  return (
    <div data-filename="pages/CodeExporter" data-linenumber="412" data-visual-selector-id="pages/CodeExporter412" className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-6">
      <div data-filename="pages/CodeExporter" data-linenumber="413" data-visual-selector-id="pages/CodeExporter413" className="max-w-4xl mx-auto">
        <div data-filename="pages/CodeExporter" data-linenumber="414" data-visual-selector-id="pages/CodeExporter414" className="flex items-center gap-4 mb-8">
          <Link data-filename="pages/CodeExporter" data-linenumber="415" data-visual-selector-id="pages/CodeExporter415" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="416" data-visual-selector-id="pages/CodeExporter416" className="bg-white/80 backdrop-blur-sm border border-slate-200 p-2 rounded-lg hover:bg-white">
              <ArrowLeft data-filename="pages/CodeExporter" data-linenumber="417" data-visual-selector-id="pages/CodeExporter417" className="w-4 h-4" />
            </button>
          </Link>
          <div data-filename="pages/CodeExporter" data-linenumber="420" data-visual-selector-id="pages/CodeExporter420">
            <h1 className="text-3xl font-bold text-slate-900">Create Flashcards</h1>
            <p data-filename="pages/CodeExporter" data-linenumber="422" data-visual-selector-id="pages/CodeExporter422" className="text-slate-600 mt-1">Generate study materials with AI or upload documents</p>
          </div>
        </div>

        <div data-filename="pages/CodeExporter" data-linenumber="426" data-visual-selector-id="pages/CodeExporter426" className="bg-white/80 backdrop-blur-sm shadow-xl border-0 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Coming Soon!</h2>
          <p data-filename="pages/CodeExporter" data-linenumber="428" data-visual-selector-id="pages/CodeExporter428" className="text-slate-600 mb-8">
            The AI-powered flashcard creation feature is under development. Soon you'll be able to:
          </p>
          <ul data-filename="pages/CodeExporter" data-linenumber="431" data-visual-selector-id="pages/CodeExporter431" className="space-y-3 text-slate-600 mb-8">
            <li data-filename="pages/CodeExporter" data-linenumber="432" data-visual-selector-id="pages/CodeExporter432" className="flex items-center gap-2">
              <span data-filename="pages/CodeExporter" data-linenumber="433" data-visual-selector-id="pages/CodeExporter433" className="w-2 h-2 bg-amber-500 rounded-full"></span>
              Generate flashcards from any topic using AI
            </li>
            <li data-filename="pages/CodeExporter" data-linenumber="436" data-visual-selector-id="pages/CodeExporter436" className="flex items-center gap-2">
              <span data-filename="pages/CodeExporter" data-linenumber="437" data-visual-selector-id="pages/CodeExporter437" className="w-2 h-2 bg-amber-500 rounded-full"></span>
              Upload documents and extract key information
            </li>
            <li data-filename="pages/CodeExporter" data-linenumber="440" data-visual-selector-id="pages/CodeExporter440" className="flex items-center gap-2">
              <span data-filename="pages/CodeExporter" data-linenumber="441" data-visual-selector-id="pages/CodeExporter441" className="w-2 h-2 bg-amber-500 rounded-full"></span>
              Create visual flashcards with AI-generated images
            </li>
            <li data-filename="pages/CodeExporter" data-linenumber="444" data-visual-selector-id="pages/CodeExporter444" className="flex items-center gap-2">
              <span data-filename="pages/CodeExporter" data-linenumber="445" data-visual-selector-id="pages/CodeExporter445" className="w-2 h-2 bg-amber-500 rounded-full"></span>
              Support for 50+ languages
            </li>
          </ul>
          <Link data-filename="pages/CodeExporter" data-linenumber="449" data-visual-selector-id="pages/CodeExporter449" to="/dashboard">
            <button data-filename="pages/CodeExporter" data-linenumber="450" data-visual-selector-id="pages/CodeExporter450" className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-6 py-3 rounded-lg font-semibold">
              Back to Dashboard
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}