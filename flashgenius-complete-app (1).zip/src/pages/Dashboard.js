import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Brain, BookOpen, Search } from 'lucide-react';

export default function Dashboard() {
  const [flashcardSets] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div data-filename="pages/CodeExporter" data-linenumber="314" data-visual-selector-id="pages/CodeExporter314" className="min-h-screen">
      {/* Hero Section */}
      <div data-filename="pages/CodeExporter" data-linenumber="316" data-visual-selector-id="pages/CodeExporter316" className="relative text-white overflow-hidden">
        <div data-filename="pages/CodeExporter" data-linenumber="317" data-visual-selector-id="pages/CodeExporter317" className="absolute inset-0 flashcard-gradient" />
        <div data-filename="pages/CodeExporter" data-linenumber="318" data-visual-selector-id="pages/CodeExporter318" className="absolute inset-0 bg-gradient-to-r from-indigo-900/40 to-purple-900/40" />
        <div data-filename="pages/CodeExporter" data-linenumber="319" data-visual-selector-id="pages/CodeExporter319" className="relative max-w-7xl mx-auto px-6 py-20 md:py-28">
          <div data-filename="pages/CodeExporter" data-linenumber="320" data-visual-selector-id="pages/CodeExporter320" className="text-center mb-8">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
              Master Any Subject
            </h1>
            <p data-filename="pages/CodeExporter" data-linenumber="324" data-visual-selector-id="pages/CodeExporter324" className="text-xl md:text-2xl text-blue-100 mb-10 max-w-3xl mx-auto font-light">
              Create AI-powered flashcards in any language, study smarter, and test your knowledge
            </p>
            <div data-filename="pages/CodeExporter" data-linenumber="327" data-visual-selector-id="pages/CodeExporter327" className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link data-filename="pages/CodeExporter" data-linenumber="328" data-visual-selector-id="pages/CodeExporter328" to="/create">
                <button data-filename="pages/CodeExporter" data-linenumber="329" data-visual-selector-id="pages/CodeExporter329" className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 px-8 py-4 text-lg rounded-lg font-semibold">
                  <Plus data-filename="pages/CodeExporter" data-linenumber="330" data-visual-selector-id="pages/CodeExporter330" className="w-6 h-6 mr-3 inline" />
                  Create Flashcards
                </button>
              </Link>
              <Link data-filename="pages/CodeExporter" data-linenumber="334" data-visual-selector-id="pages/CodeExporter334" to="/study">
                <button data-filename="pages/CodeExporter" data-linenumber="335" data-visual-selector-id="pages/CodeExporter335" className="bg-white/10 border border-white/30 text-white hover:bg-white/20 backdrop-blur-sm px-8 py-4 text-lg rounded-lg font-semibold">
                  <Brain data-filename="pages/CodeExporter" data-linenumber="336" data-visual-selector-id="pages/CodeExporter336" className="w-6 h-6 mr-3 inline" />
                  Start Studying
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div data-filename="pages/CodeExporter" data-linenumber="346" data-visual-selector-id="pages/CodeExporter346" className="bg-gradient-to-b from-slate-50 to-white">
        <div data-filename="pages/CodeExporter" data-linenumber="347" data-visual-selector-id="pages/CodeExporter347" className="max-w-7xl mx-auto px-6 py-12">
          {/* Stats Overview */}
          <div data-filename="pages/CodeExporter" data-linenumber="349" data-visual-selector-id="pages/CodeExporter349" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              { title: "Total Sets", value: "0", icon: BookOpen, color: "text-blue-600", bgColor: "bg-blue-50" },
              { title: "Total Cards", value: "0", icon: Plus, color: "text-amber-600", bgColor: "bg-amber-50" },
              { title: "Studied Today", value: "0", icon: Brain, color: "text-green-600", bgColor: "bg-green-50" },
              { title: "Progress", value: "85%", icon: BookOpen, color: "text-purple-600", bgColor: "bg-purple-50" }
            ].map((stat, index) => (
              <div data-filename="pages/CodeExporter" data-linenumber="356" data-visual-selector-id="pages/CodeExporter356" key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 p-6 rounded-lg">
                <div data-filename="pages/CodeExporter" data-linenumber="357" data-visual-selector-id="pages/CodeExporter357" className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-slate-600">{stat.title}</h3>
                  <div data-filename="pages/CodeExporter" data-linenumber="359" data-visual-selector-id="pages/CodeExporter359" className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <stat.icon className={`w-4 h-4 ${stat.color}`} />
                  </div>
                </div>
                <div data-filename="pages/CodeExporter" data-linenumber="363" data-visual-selector-id="pages/CodeExporter363" className="text-2xl font-bold text-slate-900">{stat.value}</div>
              </div>
            ))}
          </div>

          {/* Search and Create */}
          <div data-filename="pages/CodeExporter" data-linenumber="369" data-visual-selector-id="pages/CodeExporter369" className="mb-8">
            <div data-filename="pages/CodeExporter" data-linenumber="370" data-visual-selector-id="pages/CodeExporter370" className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div data-filename="pages/CodeExporter" data-linenumber="371" data-visual-selector-id="pages/CodeExporter371" className="relative flex-1 max-w-md">
                <Search data-filename="pages/CodeExporter" data-linenumber="372" data-visual-selector-id="pages/CodeExporter372" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search flashcard sets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/80 backdrop-blur-sm border border-slate-200 shadow-sm w-full px-3 py-2 rounded-lg"
                />
              </div>
              <Link data-filename="pages/CodeExporter" data-linenumber="381" data-visual-selector-id="pages/CodeExporter381" to="/create">
                <button data-filename="pages/CodeExporter" data-linenumber="382" data-visual-selector-id="pages/CodeExporter382" className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-lg hover:shadow-xl transition-all px-4 py-2 rounded-lg text-white font-semibold">
                  <Plus data-filename="pages/CodeExporter" data-linenumber="383" data-visual-selector-id="pages/CodeExporter383" className="w-4 h-4 mr-2 inline" />
                  New Set
                </button>
              </Link>
            </div>
          </div>

          {/* Flashcard Sets Grid */}
          <div data-filename="pages/CodeExporter" data-linenumber="391" data-visual-selector-id="pages/CodeExporter391" className="bg-white/80 backdrop-blur-sm text-center p-12 rounded-lg">
            <BookOpen data-filename="pages/CodeExporter" data-linenumber="392" data-visual-selector-id="pages/CodeExporter392" className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">No Flashcard Sets Yet</h3>
            <p data-filename="pages/CodeExporter" data-linenumber="394" data-visual-selector-id="pages/CodeExporter394" className="text-slate-500 mb-6">Create your first set to start studying!</p>
            <Link data-filename="pages/CodeExporter" data-linenumber="395" data-visual-selector-id="pages/CodeExporter395" to="/create">
              <button data-filename="pages/CodeExporter" data-linenumber="396" data-visual-selector-id="pages/CodeExporter396" className="gold-gradient px-6 py-3 rounded-lg text-white font-semibold">
                Create Your First Set
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}